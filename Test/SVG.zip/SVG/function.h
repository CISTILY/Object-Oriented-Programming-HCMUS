#include <iostream>
#include <fstream>
#include "Properties.h"
#include <vector>

using namespace std;

void PropertiesBuilder (char*, char*, char*, Properties &, vector<char*> &, vector<char*> &);
vector<string> getContent ();